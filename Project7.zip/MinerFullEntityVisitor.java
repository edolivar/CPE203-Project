public class MinerFullEntityVisitor extends AllFalseEntityVisitor {

    @Override
    public Boolean visit(MinerFull minerFull) {
        return true;
    }

}
