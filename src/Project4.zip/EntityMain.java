public interface EntityMain extends Entity{
    void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler eventScheduler);

}
