public interface EntityWithAnimation extends EntityMain {

    int getAnimationPeriod();

}
